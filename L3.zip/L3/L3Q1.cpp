# include <iostream>
# include <cstdlib>
# include <cstdio>
# include <sstream>
# include <algorithm>
#include <bits/stdc++.h>
using namespace std;
int ind=0;
int x[100];
int inde;
struct node
{
    int info;
    struct node *left;
    struct node *right;
    node *parent;
    char color;
    int index;
}*root;
 

class BST
{
    public:    
        void insert(node *, node *);
        void inorder(node *);
        void inorder2(node *);
        void display(node *, int);
        BST()
        {
            root = NULL;
        }
};
class RBtree
{
public:   
   node *root;
      node *q;
   
      RBtree()
      {
              q=NULL;
              root=NULL;
      }
      void insert(int z);
      void insertfix(node *);
      void leftrotate(node *);
      void rightrotate(node *);
      node* successor(node *);
      void delfix(node *);
      void disp();
      void display( node *);
      void inorder(node *);
};
class AVLtree
{
public:
 int height(node *);

        int diff(node *);

        node *rr_rotation(node *);

        node *ll_rotation(node *);

        node *lr_rotation(node *);

        node *rl_rotation(node *);

        node* balance(node *);
       
        void inorder(node *);
 
        node* insert(node *, int );

        void display(node *, int);

        AVLtree()
      {
     root=NULL;
}};

void RBtree::insert(int z)
{
     int i=0;
     node *p,*q;
     node *t=new node;
     t->info=z;
     t->left=NULL;
     t->right=NULL;
     t->color='r';
     p=root;
     q=NULL;
     if(root==NULL)
     {
           root=t;
           t->parent=NULL;
     }
     else
     {
         while(p!=NULL)
         {
              q=p;
              if(p->info<t->info)
                  p=p->right;
              else
                  p=p->left;
         }
         t->parent=q;
         if(q->info<t->info)
              q->right=t;
         else
              q->left=t;
     }
     insertfix(t);
}
void RBtree::insertfix(node *t)
{
     node *u;
     if(root==t)
     {
         t->color='b';
         return;
     }
     while(t->parent!=NULL&&t->parent->color=='r')
     {
           node *g=t->parent->parent;
           if(g->left==t->parent)
           {
                        if(g->right!=NULL)
                        {
                              u=g->right;
                              if(u->color=='r')
                              {
                                   t->parent->color='b';
                                   u->color='b';
                                   g->color='r';
                                   t=g;
                              }
                        }
                        else
                        {
                            if(t->parent->right==t)
                            {
                                 t=t->parent;
                                 leftrotate(t);
                            }
                            t->parent->color='b';
                            g->color='r';
                            rightrotate(g);
                        }
           }
           else
           {
                        if(g->left!=NULL)
                        {
                             u=g->left;
                             if(u->color=='r')
                             {
                                  t->parent->color='b';
                                  u->color='b';
                                  g->color='r';
                                  t=g;
                             }
                        }
                        else
                        {
                            if(t->parent->left==t)
                            {
                                   t=t->parent;
                                   rightrotate(t);
                            }
                            t->parent->color='b';
                            g->color='r';
                            leftrotate(g);
                        }
           }
           root->color='b';
     }
}


void RBtree::delfix(node *p)
{
    node *s;
    while(p!=root&&p->color=='b')
    {
          if(p->parent->left==p)
          {
                  s=p->parent->right;
                  if(s->color=='r')
                  {
                         s->color='b';
                         p->parent->color='r';
                         leftrotate(p->parent);
                         s=p->parent->right;
                  }
                  if(s->right->color=='b'&&s->left->color=='b')
                  {
                         s->color='r';
                         p=p->parent;
                  }
                  else
                  {
                      if(s->right->color=='b')
                      {
                             s->left->color=='b';
                             s->color='r';
                             rightrotate(s);
                             s=p->parent->right;
                      }
                      s->color=p->parent->color;
                      p->parent->color='b';
                      s->right->color='b';
                      leftrotate(p->parent);
                      p=root;
                  }
          }
          else
          {
                  s=p->parent->left;
                  if(s->color=='r')
                  {
                        s->color='b';
                        p->parent->color='r';
                        rightrotate(p->parent);
                        s=p->parent->left;
                  }
                  if(s->left->color=='b'&&s->right->color=='b')
                  {
                        s->color='r';
                        p=p->parent;
                  }
                  else
                  {
                        if(s->left->color=='b')
                        {
                              s->right->color='b';
                              s->color='r';
                              leftrotate(s);
                              s=p->parent->left;
                        }
                        s->color=p->parent->color;
                        p->parent->color='b';
                        s->left->color='b';
                        rightrotate(p->parent);
                        p=root;
                  }
          }
       p->color='b';
       root->color='b';
    }
}

void RBtree::leftrotate(node *p)
{
     if(p->right==NULL)
           return ;
     else
     {
           node *y=p->right;
           if(y->left!=NULL)
           {
                  p->right=y->left;
                  y->left->parent=p;
           }
           else
                  p->right=NULL;
           if(p->parent!=NULL)
                y->parent=p->parent;
           if(p->parent==NULL)
                root=y;
           else
           {
               if(p==p->parent->left)
                       p->parent->left=y;
               else
                       p->parent->right=y;
           }
           y->left=p;
           p->parent=y;
     }
}
void RBtree::rightrotate(node *p)
{
     if(p->left==NULL)
          return ;
     else
     {
         node *y=p->left;
         if(y->right!=NULL)
         {
                  p->left=y->right;
                  y->right->parent=p;
         }
         else
                 p->left=NULL;
         if(p->parent!=NULL)
                 y->parent=p->parent;
         if(p->parent==NULL)
               root=y;
         else
         {
             if(p==p->parent->left)
                   p->parent->left=y;
             else
                   p->parent->right=y;
         }
         y->right=p;
         p->parent=y;
     }
}

node* RBtree::successor(node *p)
{
      node *y=NULL;
     if(p->left!=NULL)
     {
         y=p->left;
         while(y->right!=NULL)
              y=y->right;
     }
     else
     {
         y=p->right;
         while(y->left!=NULL)
              y=y->left;
     }
     return y;
}

/*void RBtree::disp()
{
     display(root);
}
void RBtree::display(node *p)
{
     if(root==NULL)
     {
          cout<<"\nEmpty Tree.";
          return ;
     }
     if(p!=NULL)
     {
                cout<<"\n\t NODE: ";
                cout<<"\n info: "<<p->info;
                cout<<"\n Colour: ";
    if(p->color=='b')
     cout<<"Black";
    else
     cout<<"Red";
                if(p->parent!=NULL)
                       cout<<"\n Parent: "<<p->parent->info;
                else
                       cout<<"\n There is no parent of the node.  ";
                if(p->right!=NULL)
                       cout<<"\n Right Child: "<<p->right->info;
                else
                       cout<<"\n There is no right child of the node.  ";
                if(p->left!=NULL)
                       cout<<"\n Left Child: "<<p->left->info;
                else
                       cout<<"\n There is no left child of the node.  ";
                cout<<endl;
    if(p->left)
    {
                 cout<<"\n\nLeft:\n";
     display(p->left);
    }
    /*else
     cout<<"\nNo Left Child.\n";*/
    /*if(p->right)
    {
     cout<<"\n\nRight:\n";
                 display(p->right);
    }
    /*else
     cout<<"\nNo Right Child.\n"
     }
}*/

void RBtree::inorder(node *ptr)
{
    if (root == NULL)
    {
        cout<<"Tree is empty"<<endl;
        return;
    }
    if (ptr != NULL)
    {
        inorder(ptr->left);
        cout<<ptr->info<<"  ";
        inorder(ptr->right);
    }
}
//Print paths
int max(int a, int b)
{
    return (a > b)? a : b;
}
void print(vector<int> a){
	for(int i=0;i<a.size();i++){
		if(i==a.size()-1)
			cout<<a[i];
		else
			cout<<a[i]<<"->";
	}
}

void printpathrecursively(node* root,vector<int> a){
	if(root==NULL) //base case
		return ;
	a.push_back(root->info);
	if(!root->left && !root->right){ //leaf node reached
		print(a);
		cout<<endl;
	}
	printpathrecursively(root->left,a);//recur for left subtree
	printpathrecursively(root->right,a);//recur for right subtree
} 

void printPaths(node* root)
{
	if(root!=NULL)
        {vector<int> a;
	printpathrecursively(root,a);
        printPaths(root->left);
        printPaths(root->right);}
}

int Height(node* node1)
{
if(node1==NULL) return 0;
return max(Height(node1->left),Height(node1->right))+1;
}
void bal_fac(node* node1)
{
if(node1==NULL) return;
bal_fac(node1->left);
node1->index=Height(node1->left)-Height(node1->right);
bal_fac(node1->right);
}
void display(node* node1,int h,int H)
{
if(node1==NULL) return;
bal_fac(node1);
int space;
space=(H-h)*5;
for(int i=0;i<space;i++) 
	cout<<" ";
int m;
if(node1->index<0)
{
m=0-(node1->index);
}
else
m=(node1->index);
cout<<node1->info<<"["<<m<<"]"<<endl;
display(node1->left,h-1,H);
display(node1->right,h-1,H);

}


int main()
{
    int choice, num;
    BST bst;
    node *temp,*root2=NULL;
    RBtree obj;
    AVLtree avl;
    while (1)
    {
        cout<<"1.Insert Element "<<endl;
        cout<<"2.Inorder of BST->AVL "<<endl;
        cout<<"3.Inorder Transversals of all trees"<<endl;
        cout<<"4.print all paths of all trees"<<endl;
        cout<<"5.print all trees using level-wise indentation"<<endl;
        cout<<"6.Exit"<<endl;
        cout<<"Enter your choice : ";
        cin>>choice;
        switch(choice)
        {
        case 1:
            temp = new node;
            cout<<"Enter the number to be inserted : ";
	    cin>>temp->info;
            bst.insert(root, temp);
            obj.insert(temp->info);
            cout<<"\nNode Inserted.\n";
            break;
        case 2:
       bst.inorder2(root);
        for(inde=0;inde<ind;inde++)
        { 
         root2=avl.insert(root2,x[inde]);
         //cout<<x[inde];
        }
       break;
        case 3:
            cout<<"Inorder Traversal of BS tree:"<<endl;
            bst.inorder(root);
            cout<<endl;
            cout<<"Inorder Traversal of RB tree:"<<endl;
            obj.inorder(obj.root);
            cout<<endl;
            cout<<"Inorder Traversal of AVL tree:"<<endl;
            avl.inorder(root2);
            cout<<endl;
            break;
        case 4:
            /*cout<<"Display tree:"<<endl;
            bst.display(root,1);
            cout<<endl;
            obj.disp();*/
cout<<"for bst:"<<endl;
            printPaths(root);
cout<<"for avl:"<<endl;
printPaths(root2);
cout<<"for rbt:"<<endl;
printPaths(obj.root);
            break;
        case 5:
 	cout<<"BST TREE:"<<endl;
	display(root,Height(root),Height(root));
	cout<<endl;
 	cout<<"AVL TREE:"<<endl;
	display(root2,Height(root2),Height(root2));
	cout<<endl;
	cout<<"RB TREE:"<<endl;
	display(obj.root,Height(obj.root),Height(obj.root));
	cout<<endl;
	break;	
        
        case 6:
            exit(1);
        default:
            cout<<"Wrong choice"<<endl;
        }
    }
}


void BST::insert(node *tree, node *newnode)
{
    if (root == NULL)
    {
        root = new node;
        root->info = newnode->info;
        root->left = NULL;
        root->right = NULL;
        cout<<"Root Node is Added"<<endl;
        return;
    }
    if (tree->info == newnode->info)
    {
        cout<<"Element already in the tree"<<endl;
        return;
    }
    if (tree->info > newnode->info)
    {
        if (tree->left != NULL)
        {
            insert(tree->left, newnode);	
	}
	else
	{
            tree->left = newnode;
            (tree->left)->left = NULL;
            (tree->left)->right = NULL;
            cout<<"Node Added To Left"<<endl;
            return;
        }
    }
    else
    {
        if (tree->right != NULL)
        {
            insert(tree->right, newnode);
        }
        else
        {
            tree->right = newnode;
            (tree->right)->left = NULL;
            (tree->right)->right = NULL;
            cout<<"Node Added To Right"<<endl;
            return;
        }	
    }
}



void BST::inorder(node *ptr)
{
    if (root == NULL)
    {
        cout<<"Tree is empty"<<endl;
        return;
    }
    if (ptr != NULL)
    {
        inorder(ptr->left);
        cout<<ptr->info<<"  ";
        inorder(ptr->right);
    }
}
void BST::inorder2(node *ptr)
{
if(root==NULL)
{
return;
}
if(ptr !=NULL)
{
inorder2(ptr->left);
x[ind++]=ptr->info;
inorder2(ptr->right);
}
}
 
void BST::display(node *ptr, int level)
{
    int i;
    if (ptr != NULL)
    {
        display(ptr->right, level+1);
        cout<<endl;
        if (ptr == root)
            cout<<"Root->:  ";
        else
        {
            for (i = 0;i < level;i++)
                cout<<"       ";
	}
        cout<<ptr->info;
        display(ptr->left, level+1);
    }
}
int AVLtree::height(node *temp)

{

    int h = 0;

    if (temp != NULL)

    {

        int l_height = height (temp->left);

        int r_height = height (temp->right);

        int max_height = max (l_height, r_height);

        h = max_height + 1;

    }

    return h;

}


int AVLtree::diff(node *temp)

{

    int l_height = height (temp->left);

    int r_height = height (temp->right);

    int b_factor= l_height - r_height;

    return b_factor;

}

 



node *AVLtree::rr_rotation(node *parent)

{

    node *temp;

    temp = parent->right;

    parent->right = temp->left;

    temp->left = parent;

    return temp;

}



node *AVLtree::ll_rotation(node *parent)

{

    node *temp;

    temp = parent->left;

    parent->left = temp->right;

    temp->right = parent;

    return temp;

}

 

node *AVLtree::lr_rotation(node *parent)

{

    node *temp;

    temp = parent->left;

    parent->left = rr_rotation (temp);

    return ll_rotation (parent);

}

 

node *AVLtree::rl_rotation(node *parent)

{

    node *temp;

    temp = parent->right;

    parent->right = ll_rotation (temp);

    return rr_rotation (parent);

}


node *AVLtree::balance(node *temp)

{

    int bal_factor = diff (temp);

    if (bal_factor > 1)

    {

        if (diff (temp->left) > 0)

            temp = ll_rotation (temp);

        else

            temp = lr_rotation (temp);

    }

    else if (bal_factor < -1)

    {

        if (diff (temp->right) > 0)

            temp = rl_rotation (temp);

        else

            temp = rr_rotation (temp);

    }

    return temp;

}



node *AVLtree::insert(node *root, int value)

{

    if (root == NULL)

    {

        root = new node;

        root->info = value;

        root->left = NULL;

        root->right = NULL;

        return root;

    }

    else if (value < root->info)

    {

        root->left = insert(root->left, value);

        root = balance (root);

    }

    else if (value >= root->info)

    {

        root->right = insert(root->right, value);

        root = balance (root);

    }

    return root;
}

void AVLtree::inorder(node *tree)

{

    if (tree == NULL)

        return;

    inorder (tree->left);

    cout<<tree->info<<"  ";

    inorder (tree->right);

}

