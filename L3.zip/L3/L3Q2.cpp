#include <iostream>
using namespace std;

struct Node {
    int info,key;
    Node* next;
};

int ind=0;
void insert(Node** root, int value)
{
    Node* temp = new Node;
    Node* ptr;
    temp->info = value;
    temp->next = NULL;
    temp->key=ind;
    ind++;

    if (*root == NULL)
        *root = temp;
    else {
        ptr = *root;
        while (ptr->next != NULL)
            ptr = ptr->next;
        ptr->next = temp;
    }
}

/*void display(Node root)
{
    while (root != NULL) {
        cout << root->info << " "<<root->index<<endl;
        root = root->next;
    }
}*/

Node *createListFromArray(int arr[], int n)
{
    Node *root = NULL;
    for (int j = 0; j < n; j++)
        insert(&root, arr[j]);
   return root;
}

int main()
{
    int n;
   cout<<"Enter the number of numbers to be inserted"<<endl;
    cin >> n;

   int *b = new int[n] ;
  cout<<"Enter the numbers to be inserted"<<endl;

for (int i = 0; i < n; ++i)
{
    cin >> b[i] ;
}
    Node* root = createListFromArray(b, n);
int count  = 0 ;
/*for(int i=0;i<n;i++){
    for(int j =i+1;j<n;j++){
        for(int k=j;k<n;k++){
            for(int p=i;p<)
        }
    }
}*/

Node* sam1;
Node* sam2;
Node* sam3;
Node* sam;
int p,q;
//cin>>n;
int a[n][n];
for(int i=0;i<n;i++){
    for(int j=0;j<n;j++){
        a[i][j] = -1;
    }
}
sam1 = root;
while(sam1->next!=NULL)
      {sam2=sam1->next;
		while(sam2!=NULL){
		    sam3=sam2;
			while(sam3!=NULL){
			    p=q=0;
			    sam=sam1;
			    if(a[sam1->key][sam2->key]!= -1){
		           p = a[sam1->key][sam2->key];		
			    }
			    else{
                    
		    while(sam!=sam2){
					p=p^(sam->info);
					sam=sam->next;
				}
				a[sam1->key][sam2->key-1] = p;
			    }
			    if(a[sam2->key][sam3->key]!=-1){
			    q = a[sam2->key][sam3->key];
			    }
			    else{
                    
                    while(sam!=sam3){
					q=q^(sam->info);
					sam=sam->next;
    
				}
				q=q^(sam3->info);
				a[sam2->key][sam3->key] = q;
			    }
			   // cout<<p<<" "<<q<<endl;
			    if(p==q){
                    count++;

                    cout<<sam1->key+1<<" "<<sam2->key+1<<" "<<sam3->key+1<<endl;
			    }
    sam3=sam3->next;
        }sam2=sam2->next;
    }sam1=sam1->next;
    }
     cout<<count<<endl;
}
