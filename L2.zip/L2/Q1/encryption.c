#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{char s[100];int h=0;
	 FILE *fptr;
    char ch;
    fptr = fopen("input.txt", "r");
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        return 0;
    }
    ch = fgetc(fptr);
    s[0]=ch;
    h=1;
    while (ch != EOF)
    {	
        printf ("%c", ch);
        ch = fgetc(fptr);
        s[h]=ch;
		h++;
    }
    fclose(fptr);
    
    printf("\n");		
    int n,a,b;
    printf("enter values of n,a,b\n");
    scanf("%d%d%d",&n,&a,&b);
   
    int l=h-2;
    int c=l/n;
    int k=l;
    int i;
    char arr1[100];
    char arr2[100];
    int x=0;
    int extra;
    if(l%n==0)
    {
    	extra=l;
 
        for( i=0;i<l;i++)
        {
            arr1[i]=s[i];
        }
    }
    else
    {
     extra=(c+1)*n;
       for( i=0;i<l;i++)
        {
            arr1[i]=s[i];
        }

        for( i=l;i<extra;i++)
        {
            arr1[i]='\0';
        }
 
    }
    for( k=0;k<extra;k+=5)
    {
        for( i=0;i<5;i++)
        {
 
             int j=(a*i+b)%n;
            arr2[x]=arr1[j+k];
            x++;
        }
    }
    for( k=0;k<extra;k++)
    {
        printf("%c",arr2[k]);
    }
   
   FILE *fpt;
   fpt= fopen("output.txt", "w");
   if(fpt == NULL)
   {
      printf("Error!");
      exit(1);
   }
   
   for(k=0;k<extra;k++)
    {
     fprintf(fpt,"%c", arr2[k]);  
    }
   fclose(fpt);
   
 
 
 
    return 0;
}
