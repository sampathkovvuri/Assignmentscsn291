#include <stdio.h>
#include <stdlib.h>
int main()
{char s[100];
int h=0;
int i;
	 FILE *fptr;
    char ch;
    fptr = fopen("input.txt", "r");
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        return 0;
    }
    ch = fgetc(fptr);
    s[0]=ch;
    h=1;
    while (ch != EOF)
    {	
        printf ("%c", ch);
        ch = fgetc(fptr);
        s[h]=ch;
		h++;
    }
    fclose(fptr);


 char m[100];
     int n=0;
	 FILE *fpt;
    char ch2;
    fpt = fopen("decryptedoutput.txt", "r");
    if (fpt == NULL)
    {
        printf("Cannot open file \n");
        return 0;
    }
    ch2 = fgetc(fpt);
    m[0]=ch2;
    n=1;
    while (ch2 != EOF)
    {	
        printf ("%c", ch2);
        ch2 = fgetc(fpt);
        m[n]=ch2;
		n++;
    }
    fclose(fpt);
for(i=0;i<h-2;i++)
{if(s[i]!=m[i])
{
printf("\nnotsame");
break;
}
}
printf("\nsame");
}
	
