#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
char s[100];int h=0;
	 FILE *fptr;
    char ch;
    fptr = fopen("output.txt", "r");
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        return 0;
    }
    ch = fgetc(fptr);
    s[0]=ch;
    h=1;
    while (ch != EOF)
    {	
        printf ("%c", ch);
        ch = fgetc(fptr);
        s[h]=ch;
		h++;
    }
    fclose(fptr);

	printf("\n");
	
	 int n,a,b;
    printf("enter values of n,a,b\n");
    scanf("%d%d%d",&n,&a,&b);
   
    int l=h-2;
    int c=l/n;
    int k=l;
    int i;
    char arr1[100];
    char arr2[100];
    int x=0;
    int extra;
    if(l%n==0)
    {
    	extra=l;
 
        for( i=0;i<l;i++)
        {
            arr1[i]=s[i];
        }
    }
    else
    {
     extra=(c+1)*n;
        for( i=0;i<extra;i++)
        {
            if(i<l)
            arr1[i]=s[i];
            else
            arr1[i]='\0';
        }
 
    }
    int a1,b1;
    for( h=0;h<n;h++){
    	if((h*n)%a==1)
    	{
    		a1=(h*n+1)%a;
    		b1=n-((a1*b)%n);
		}
	}
    for( k=0;k<extra;k+=5)
    {
        for( i=0;i<5;i++)
        {
 
             int j=(a1*i+b1)%n;
            arr2[x]=arr1[j+k];
            x++;
        }
    }
    for( k=0;k<extra;k++)
    {
        printf("%c",arr2[k]);
    }
   
   FILE *fpt;
   fpt= fopen("decryptedoutput.txt", "w");
   if(fpt == NULL)
   {
      printf("Error!");
      exit(1);
   }
   
 
   for(k=0;k<extra;k++)
    {
     fprintf(fpt,"%c", arr2[k]);  
    }
   fclose(fpt);
   
 
 
 
    return 0;
}
