#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
int count=0;
int count2=0;

bool all_same(int r,int x[r][r],int a1,int a2,int b1,int b2)
{
	int i,j;
	for(i=a1;i<a2;i++)
	{
		for(j=b1;j<b2;j++)
		{
			if(x[a1][b1]!=x[i][j])	
			{
			return false;
			}
	
				}
	}
	return true;
}
  void maximal_array(int r,int x[r][r],int a1,int a2,int b1,int b2,int max[r][r])
  {
  	int max_array[r][r];
  	if(all_same(r,x,a1,a2,b1,b2))
  	{
  		int i,j;
  		count++;
  		for(i=a1;i<a2;i++)
  		{
  			for(j=b1;j<b2;j++)
  			{
  				max[i][j]=count;
			  }
		  }
	  }
	  else
	  {
	  	maximal_array(r,x,a1,(a1+a2)/2,b1,(b1+b2)/2,max);
	  	maximal_array(r,x,a1,(a1+a2)/2,(b1+b2)/2,b2,max);
	  	maximal_array(r,x,(a1+a2)/2,a2,b1,(b1+b2)/2,max);
	  	maximal_array(r,x,(a1+a2)/2,a2,(b1+b2)/2,b2,max);
	  }

  }
   int get(int x){
	  int z=1;
	  while(z<x)
	  {
	  	z=z*2;
	  	}
	  	return z;
	  }	  
	  
	   void quad_tree(int r,int x[r][r],int a1,int a2,int b1,int b2,int max[r][r],int height)
  {
  	int max_array[r][r];
  	if(all_same(r,x,a1,a2,b1,b2))
  	{
  		int i,j;
  		count2++;
  		printf("(%d,%d,%d)\n",count2,height,x[a1][b1]);  		
  		for(i=a1;i<a2;i++)
  		{
  			for(j=b1;j<b2;j++)
  			{
  				max[i][j]=count2;
			  }
		  }
	  }
	  else
	  {
	  	height++;
	quad_tree(r,x,a1,(a1+a2)/2,b1,(b1+b2)/2,max,height);
    quad_tree(r,x,a1,(a1+a2)/2,(b1+b2)/2,b2,max,height);
    quad_tree(r,x,(a1+a2)/2,a2,b1,(b1+b2)/2,max,height);
    quad_tree(r,x,(a1+a2)/2,a2,(b1+b2)/2,b2,max,height);
	  }
}

  int main(){
  	int p=0,q=0;
   FILE *file  = NULL;
    int symbol  = 0,
        columns = 0,
        rows    = -1;
    file = fopen("input2.txt", "r");
    if (file != NULL)
    {
        do
        {
        
            symbol = fgetc(file);
            
            if (rows == 0 && (isspace(symbol) || feof(file)))
            {
                columns++;
            }
            if (symbol == '\n' || feof(file))
            {
                rows++;
            }
        }
        while (symbol != EOF);
        if (ferror(file))
        {
            printf("Error on reading from file.\n");
        }
        else
        {
            printf("The file contains %d row(s) and %d column(s).\n", rows, columns);
    }
        fclose(file);
    }
    
    else
    {
        perror("Error on opening the input file");
   }
   FILE *ftr=NULL;
   ftr=fopen("input2.txt","r");
   int read;
   int arr[rows][rows];
   while(EOF!=fscanf(ftr,"%d",&read))
   {
   	arr[p][q]=read;
   	q++;
   	if(q==rows)
   	{
   		q=0;
   		p++;
	   }
	  }   
	  for(p=0;p<rows;p++)
	  {
	  	printf("\n");
	  	for(q=0;q<rows;q++)
	  	{
	  		printf("%d",arr[p][q]);
		  }
	  }
	  int z;
z=get(rows);
printf("\n");
	  int arr1[z][z];
	  for( p=0;p<z;p++)
	  {
	  	for( q=0;q<z;q++)
	  	{
	  		arr1[p][q]=0;
		  }
		
	  }
	  
	for( p=z-rows;p<z;p++)
	{
		for( q=z-rows;q<z;q++)
		{
			arr1[p][q]=arr[p+rows-z][q+rows-z];
		}
			}	
for(p=0;p<z;p++){

for(q=0;q<z;q++)
printf("%d\t",arr1[p][q]);
printf("\n");
}
int arr2[z][z];
maximal_array(z,arr1,0,z,0,z,arr2);
printf("\n");
printf("\n");
for(p=0;p<z;p++){

for(q=0;q<z;q++)
printf("%d\t",arr2[p][q]);
printf("\n");
}
quad_tree(z,arr1,0,z,0,z,arr2,0);
}
